import package2.program1;
public class program1new {
    public static void main(String[] args) {
        program1 p=new program1(65);
        p.calculate_grade();
        p.display();
    }
}
