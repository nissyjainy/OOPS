
import java.util.*;
public class program2 {
    public static void main(String[] args) {
        try {
            Scanner s1=new Scanner(System.in);
            System.out.println("enter the values");

            int a=s1.nextInt();
            int b=s1.nextInt();
            int c=a/b;
            System.out.println("value: "+c);
        } catch (ArithmeticException e) {
            System.out.println("please don't divide any number by zero");
        }
        finally{
            System.out.println("Program executed Successfully");
        }
    }
}
